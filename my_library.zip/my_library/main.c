#include <stdio.h>
#include <stdlib.h>
#include "geolib.h"

int arr_size;

int main()
{
    int *arr = (int*) malloc(arr_size*sizeof(int));

    printf("Insert array size: ");
    scanf("%d",&arr_size);
    
    arr = read_array(arr_size);
    int *arr_copy = arr; // does not create a copy of the array it just copies the pointer that points to the start of it
    print_array(arr_copy,arr_size);    
    
    
    free(arr);


    return 0;
}